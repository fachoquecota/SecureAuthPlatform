﻿namespace AuthAPI.Models
{
    public class RoleModel
    {
        public int roleId { get; set; }
        public string roleName { get; set; }
        public string description { get; set; }
    }
}
