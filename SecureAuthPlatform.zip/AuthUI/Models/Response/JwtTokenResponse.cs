﻿namespace AuthUI.Models.Response
{
    public class JwtTokenResponse
    {
        public string token { get; set; }
    }
}
